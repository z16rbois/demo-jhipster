/**
 * JPA domain objects.
 */
package com.decathlon.demo.domain;
