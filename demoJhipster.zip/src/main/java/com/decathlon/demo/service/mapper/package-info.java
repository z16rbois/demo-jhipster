/**
 * MapStruct mappers for mapping domain objects and Data Transfer Objects.
 */
package com.decathlon.demo.service.mapper;
