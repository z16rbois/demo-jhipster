/**
 * Service layer beans.
 */
package com.decathlon.demo.service;
