/**
 * Data Transfer Objects.
 */
package com.decathlon.demo.service.dto;
