/**
 * Spring Framework configuration files.
 */
package com.decathlon.demo.config;
