/**
 * Spring MVC REST controllers.
 */
package com.decathlon.demo.web.rest;
