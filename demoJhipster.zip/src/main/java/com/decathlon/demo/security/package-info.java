/**
 * Spring Security configuration.
 */
package com.decathlon.demo.security;
