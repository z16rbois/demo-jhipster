/**
 * Spring Data JPA repositories.
 */
package com.decathlon.demo.repository;
